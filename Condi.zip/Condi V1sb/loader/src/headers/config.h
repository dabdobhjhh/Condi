#pragma once

#define HTTP_SERVER "151.244.72.224"
#define HTTP_PORT 80

#define TFTP_SERVER "151.244.72.224"
